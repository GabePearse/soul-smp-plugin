package me.Evil.soulSMP.upkeep;

public enum UpkeepStatus {
    PROTECTED,
    UNSTABLE,
    UNPROTECTED
}