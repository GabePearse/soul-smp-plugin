package me.Evil.soulSMP.shop;

import me.Evil.soulSMP.team.Team;
import me.Evil.soulSMP.upkeep.TeamUpkeepManager;
import me.Evil.soulSMP.upkeep.UpkeepStatus;
import me.Evil.soulSMP.util.CostUtils;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/**
 * Builds the Banner Shop GUI from YAML config.
 */
public class TeamBannerShopGui {

    private static final int SHOP_SIZE = 54;

    public static void open(Player player,
                            Team team,
                            BannerShopSettings settings,
                            TeamUpkeepManager upkeepManager) {

        Inventory inv = Bukkit.createInventory(
                new TeamBannerShopHolder(team),
                settings.getSize(),
                settings.getTitle()
        );

        // Precompute upkeep info if manager is provided
        int weeksOwed = 1;
        int totalCost = 0;
        String statusText = "";
        UpkeepStatus status = null;

        if (upkeepManager != null) {
            // Make sure the team state is current
            upkeepManager.updateTeamUpkeep(team);

            weeksOwed = Math.max(1, team.getUnpaidWeeks());
            status = team.getUpkeepStatus();
            totalCost = upkeepManager.getWeeklyCostBase() * weeksOwed;
            statusText = formatUpkeepStatus(status);
        }

        for (BannerShopItem item : settings.getItems()) {
            ItemStack stack = new ItemStack(item.getMaterial());
            ItemMeta meta = stack.getItemMeta();
            if (meta == null) continue;

            // Name
            if (item.getDisplayName() != null) {
                meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',
                        item.getDisplayName()));
            }

            // Lore
            List<String> cfgLore = item.getLore(); // assuming BannerShopItem has getLore()
            if (cfgLore != null && !cfgLore.isEmpty()) {
                List<String> lore = new ArrayList<>();

                for (String raw : cfgLore) {
                    String line = ChatColor.translateAlternateColorCodes('&', raw);

                    // 🔥 Dynamic lore for the upkeep item
                    if (item.getType() == BannerShopItem.ShopItemType.UPKEEP && upkeepManager != null) {
                        line = line
                                .replace("{weeks}", String.valueOf(weeksOwed))
                                .replace("{cost}", String.valueOf(totalCost))
                                .replace("{status}", statusText);
                    }

                    lore.add(line);
                }

                meta.setLore(lore);
            }

            stack.setItemMeta(meta);
            inv.setItem(item.getSlot(), stack);
        }

        player.openInventory(inv);
    }

    // Backwards-compatible overload (if anything old still calls it)
    public static void open(Player player,
                            Team team,
                            BannerShopSettings settings) {
        open(player, team, settings, null);
    }

    private static String formatUpkeepStatus(UpkeepStatus status) {
        if (status == null) return ChatColor.GRAY + "Unknown";

        return switch (status) {
            case PROTECTED -> ChatColor.GREEN + "Protected";
            case UNSTABLE -> ChatColor.YELLOW + "Unstable";
            case UNPROTECTED -> ChatColor.DARK_RED + "Unprotected";
        };
    }

    private static String applyPlaceholders(String line, BannerShopItem item, Team team) {
        switch (item.getType()) {

            case RADIUS -> {
                int currentRadius = team.getClaimRadius();
                int max = item.getMaxRadius();
                // radius 1 -> step 0, radius 2 -> step 1, etc.
                int step = currentRadius - 1;
                int cost = CostUtils.computeCost(item.getBaseCost(), item.getCostMultiplier(), step);

                line = line
                        .replace("{current_radius}", String.valueOf(currentRadius))
                        .replace("{max_radius}", String.valueOf(max))
                        .replace("{cost}", String.valueOf(cost));
            }

            case LIVES -> {
                int lives = team.getLives();
                // lives are flat cost here; multiplier can still be used if you want scaling
                int cost = item.getScaledCost(0);

                line = line
                        .replace("{current_lives}", String.valueOf(lives))
                        .replace("{cost}", String.valueOf(cost));
            }

            case STORAGE -> {
                int currentSlots = team.getVaultSize();
                int cost = item.getScaledCost(currentSlots - 1);

                line = line
                        .replace("{current_slots}", String.valueOf(currentSlots))
                        .replace("{cost}", String.valueOf(cost));
            }

            case DIMENSION_BANNER -> {
                int cost = item.getBaseCost();
                boolean unlocked = team.hasDimensionalBannerUnlocked(item.getDimensionKey());
                line = line
                        .replace("{cost}", String.valueOf(cost))
                        .replace("{status}", unlocked ? "Unlocked" : "Locked");
            }

            case DIMENSION_TELEPORT -> {
                int cost = item.getBaseCost();
                boolean unlocked = team.hasDimensionalTeleportUnlocked(item.getDimensionKey());
                line = line
                        .replace("{cost}", String.valueOf(cost))
                        .replace("{status}", unlocked ? "Unlocked" : "Locked");
            }


            default -> {
                // no placeholders
            }
        }

        return line;
    }
}
